#pragma once

#include "abstract_compare.h"
#include "point.h"

AbstractCompare<int>* get_compare_int(int type);
AbstractCompare<Point>* get_compare_point(int type);

class AbstractCompare_int_1: public AbstractCompare<int> {
public:
    bool compare(int a, int b);
};
class AbstractCompare_int_2: public AbstractCompare<int> {
public:
    bool compare(int a, int b);
};
class AbstractCompare_point_3: public AbstractCompare<Point> {
public:
    bool compare(Point a, Point b);
};
class AbstractCompare_point_4: public AbstractCompare<Point> {
public:
    bool compare(Point a, Point b);
};