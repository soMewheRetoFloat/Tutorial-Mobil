#include "compare.h"
#include "abstract_compare.h"

bool AbstractCompare_int_1::compare(int a, int b) {
    return a < b;
}

bool AbstractCompare_int_2::compare(int a, int b) {
    int ax = 0, bx = 0, tmp_a = a, tmp_b = b;
    while (tmp_a) {
        ax += (tmp_a % 10);
        tmp_a /= 10;
    }
    while (tmp_b) {
        bx += (tmp_b % 10);
        tmp_b /= 10;
    }
    if (ax != bx) {
        return ax < bx;
    }
    else {
        return a < b;
    }
}

bool AbstractCompare_point_3::compare(Point a, Point b) {
    if (a.x != b.x) {
        return a.x < b.x;
    }
    else {
        return a.y < b.y;
    }
}

bool AbstractCompare_point_4::compare(Point a, Point b) {
    Point tmp_a = a, tmp_b = b;
    int ao = (tmp_a.x * tmp_a.x) + (tmp_a.y * tmp_a.y), 
    bo = (tmp_b.x * tmp_b.x) + (tmp_b.y * tmp_b.y);
    if (ao != bo) {
        return ao < bo;
    }
    else {
        if (a.x != b.x) {
            return a.x < b.x;
        }
        else {
            return a.y < b.y;
        }
    }
}

AbstractCompare<int>* get_compare_int(int type){
    AbstractCompare<int>* tmp;
    if (type == 1) {
        tmp = new AbstractCompare_int_1();
        return tmp;
    }
    else {
        tmp = new AbstractCompare_int_2();
        return tmp;
    }
}

AbstractCompare<Point>* get_compare_point(int type) {
    AbstractCompare<Point>* tmp;
    if (type == 3) {
        tmp = new AbstractCompare_point_3();
        return tmp;
    }
    else {
        tmp = new AbstractCompare_point_4();
        return tmp;
    }
}