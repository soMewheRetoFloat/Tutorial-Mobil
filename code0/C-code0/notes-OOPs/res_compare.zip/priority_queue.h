#pragma once
#include "abstract_compare.h"
#include "compare.h"

template<class T> class PriorityQueue {
private:
    int array_size = 200;
    int pos = -1;
    T* elem;
    int true_size = 0;
    AbstractCompare<T>* rule;
public:
    void double_size() {
        int pre = array_size;
        array_size *= 2;
        T* tmp = new T[array_size + 1];
        for (int i = 1; i <= pre; ++i) {
            tmp[i] = elem[i];
        }
        delete []elem;
        elem = tmp;
    }
    PriorityQueue(AbstractCompare<T> *_cmp): rule(_cmp) {
        elem = new T[array_size + 1];
        true_size = 0;
        pos = -1;
    };

    ~PriorityQueue() {
        delete[] elem;
    }

    bool empty() {
        return (size() <= 0);
    }

    int size() {
        return true_size;
    }

    void push(T element) {
        if (true_size >= array_size) {
            double_size();
        }
        if (empty()) {
            elem[++true_size] = element;
        }
        else {
            int tmp_size = true_size;

            for (int i = 1; i <= true_size; ++i) {
                if (rule -> compare(elem[i], element)) {
                    for (int j = true_size; j >= i; --j) {
                        elem[j + 1] = elem[j];
                    }
                    elem[i] = element;
                    true_size++;
                    break;
                }
            }
            if (tmp_size == true_size) {
                elem[++true_size] = element;
            }
        }
    }

    void pop() {
        true_size--;
    }

    T top() {
    return elem[true_size];
    }   
};