#pragma once
#include <iostream>
#include <vector>
using namespace std;

class Rack {
 private:
    vector<int> matter;
 public:
    Rack() {matter.clear();};

    Rack& operator+= (const int &rhs) {
        this -> matter.push_back(rhs);
        return *this;
    };

    Rack& operator+= (const Rack &rhs) {
        int s = rhs.matter.size();
        for (int i = 0; i < s; ++i) {
            this -> matter.push_back(rhs.matter[i]);
        }
        return *this;
    }

    Rack& operator-- () {
        for (int i = 1; i < (this -> matter.size()); ++i) {
            this -> matter[i - 1] = this -> matter[i];
        }
        this -> matter.pop_back();
        return *this;
    }

    Rack& operator-- (int dummy) {
        this -> matter.pop_back();
        return *this;
    };

    int operator() (int index) {
        int cnt = 0;
        for (auto i: (this -> matter)) {
            if (index == i) ++cnt;
        }
        return cnt;
    };

    Rack& operator~ () {
        Rack tmp;
        for (int i = (this -> matter.size() - 1); i > -1; --i) {
            tmp.matter.push_back(this -> matter[i]);
        }
        for (int i = (this -> matter.size() - 1); i > -1; --i) {
            this -> matter[i] = tmp.matter[i];
        }
        return *this;
    };

    friend bool IN(const int x, const Rack& src);
    friend Rack operator& (const Rack& lhs, const Rack& rhs);

    friend Rack operator, (const Rack& lhs, const Rack& rhs);
    friend Rack operator, (const int& lhs, const Rack& rhs);
    friend Rack operator, (const Rack& lhs, const int& rhs);
    friend bool operator== (const Rack& lhs, const Rack& rhs);
    friend bool operator> (const Rack& lhs, const Rack& rhs);
    friend bool operator< (const Rack& lhs, const Rack& rhs);

    

    friend ostream& operator<< (ostream& out, const Rack& src);
};