#include "Rack.h"

ostream& operator<<(ostream& out, const Rack& src) {
    for (int i = 0; i < src.matter.size(); ++i) {
        out << " " << src.matter[i];
    }
    return out;
};

Rack operator, (const Rack& lhs, const Rack& rhs) {
    Rack *tmp = new Rack;
    *tmp += lhs;
    *tmp += rhs;
    return *tmp;
}

Rack operator, (const int& lhs, const Rack& rhs) {
    Rack *tmp = new Rack;
    *tmp += lhs;
    *tmp += rhs;
    return *tmp;
}

Rack operator, (const Rack& lhs, const int& rhs) {
    Rack *tmp = new Rack;
    *tmp += lhs;
    *tmp += rhs;
    return *tmp;
}

bool IN(const int x, const Rack& src) {
        for (int i = 0; i < src.matter.size(); ++i) {
            if (x == src.matter[i]) {
                return true;
            }
        }
        return false;
    };

Rack operator& (const Rack& lhs, const Rack& rhs) {
    Rack *tmp = new Rack;
    for (int i = 0; i < lhs.matter.size(); ++i) {
        if (IN(lhs.matter[i], rhs) && !IN(lhs.matter[i], *tmp)) {
            tmp -> matter.push_back(lhs.matter[i]);
        }
    }
    return *tmp;
}

bool operator== (const Rack& lhs, const Rack& rhs) {
    return (lhs.matter.size() == rhs.matter.size());
}

bool operator< (const Rack& lhs, const Rack& rhs) {
    return (lhs.matter.size() < rhs.matter.size());
}

bool operator> (const Rack& lhs, const Rack& rhs) {
    return (lhs.matter.size() > rhs.matter.size());
}