#pragma once
#include "operation.h"
#include "node.h"

class Oplus : public OperationNodeTwo {
public:
    Oplus(string name, Node *x1, Node *x2) : OperationNodeTwo(name, x1, x2) {};

    void UpdateValue() override {
        value_ = input1->value() + input2->value();
    }
};

class Osubt : public OperationNodeTwo {
public:
    Osubt(string name, Node *x1, Node *x2) : OperationNodeTwo(name, x1, x2) {};

    void UpdateValue() override {
        value_ = input1->value() - input2->value();
    }
};