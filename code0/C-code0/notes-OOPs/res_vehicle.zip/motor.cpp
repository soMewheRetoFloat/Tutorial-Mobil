#include "vehicle.h"
#include "wheel.h"
#include "engine.h"
#include "motor.h"

void Motor::describe() {
    cout << "A motor with " << wheels.get_num()
    << " wheels and a " << engine.get_name() 
    << " engine." << endl;
    return;
}

void Motor::sell() {
    cout << "A motor is sold!" << endl;
    return;
}