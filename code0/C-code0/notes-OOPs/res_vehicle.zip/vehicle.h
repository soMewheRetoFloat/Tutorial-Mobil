#pragma once
#include <iostream>
#include <string>
#include "engine.h"
#include "wheel.h"
using namespace std;

class Vehicle {
 protected:
    Engine engine;
    Wheel wheels;
 public:
    Vehicle(): wheels(0), engine("none") {};
    Vehicle(int num, string name): wheels(num), engine(name) {};
    void describe();
};