#pragma once
#include <iostream>
#include <string>
#include "vehicle.h"
using namespace std;

class Car: public Vehicle {
 public:
    Car(int num, string name): Vehicle(num, name) {
        cout << "Finish building a car with " 
        << wheels.get_num()
        << " wheels and a " << engine.get_name()
        << " engine." << endl;
    };
    void describe();
};