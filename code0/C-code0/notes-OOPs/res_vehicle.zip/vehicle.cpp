#include "vehicle.h"
#include "wheel.h"
#include "engine.h"

void Vehicle::describe() {
    cout << "Finish building a vehicle with " 
    << wheels.get_num()
    << " wheels and a " << engine.get_name()
    << " engine." << endl;
    cout << "A vehicle with " << wheels.get_num()
    << " wheels and a " << engine.get_name() 
    << " engine." << endl;
    return;
}