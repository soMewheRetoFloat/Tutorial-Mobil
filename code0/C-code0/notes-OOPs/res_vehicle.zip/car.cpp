#include "vehicle.h"
#include "car.h"
#include "wheel.h"
#include "engine.h"

void Car::describe() {
    cout << "A car with " << wheels.get_num()
    << " wheels and a " << engine.get_name() 
    << " engine." << endl;
    return;
}