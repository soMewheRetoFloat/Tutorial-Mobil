#pragma once
#include <iostream>
#include <string>
#include "vehicle.h"
using namespace std;

class Motor: public Vehicle {
 public:
    Motor(int num, string name): Vehicle(num, name) {
        cout << "Finish building a motor with " 
        << wheels.get_num()
        << " wheels and a " << engine.get_name()
        << " engine." << endl;
    };
    void describe();
    void sell();
};