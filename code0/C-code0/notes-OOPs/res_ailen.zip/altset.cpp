#include "altset.h"
using namespace std;

void Altset::inverse(int index) {
    if(data[index] == '0') {
        data[index] = '1';
    }
    else if (data[index] == '1') {
        data[index] = '0';
    }
    return;
}

void Altset::append(int value) {
    ++length;
    if (length >= maxlen) {
        maxlen *= 2;
        char* tmp = new char[maxlen];
        for (int i = 0; i < length - 1; ++i) {
            tmp[i] = data[i];
        }
        delete[] data;
        data = tmp;
    }
    if (value) {
        data[length - 1] = '1';
    }
    else {
        data[length - 1] = '0';
    }
    return;
}