#pragma once

class Altset {
private:
    char *data = nullptr;
    int length = -1;
    int maxlen = 0;
public:
    Altset(): data(nullptr), length(-1), maxlen(0) {};
    ~Altset() { if (data) {delete[] data;} };

    Altset(const char *data, int len): length(len) { //构造
        this -> maxlen = 2 * len;
        this -> data = new char[maxlen];
        for (int i = 0; i < len; ++i) {
            this -> data[i] = data[len - 1 - i];
        }
    };

	Altset& operator = (const Altset &altset) { //拷贝
        this -> length = altset.length;
        this -> maxlen = altset.maxlen;
        this -> data = new char[maxlen];
        for (int i = 0; i < (this -> length); ++i) {
            this -> data[i] = altset.data[i];
        }
        return *this;
    };

    Altset& operator = (Altset &&altset) { //移动
        this -> data = altset.data;
        this -> length = altset.length;
        this -> maxlen = altset.maxlen;
        altset.data = nullptr;
        altset.length = -1;
        altset.maxlen = 0;
        return *this;
    };

    void inverse(int index);
    void append(int value);
    bool get(int index) const {
        return (bool)(data[index] - '0');
    };
    bool empty() const {
        return (length == -1);
    };
    int count() const {
        int cnt = 0;
        for (int i = 0; i < length; ++i) {
            if(data[i] - '0') ++cnt;
        }
        return cnt;
    };
};
