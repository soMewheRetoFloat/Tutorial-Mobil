#include<iostream>
#pragma once

using std::cout;
using std::endl;

template<typename T>
class my_ptr {
private:
    T* _data;
    static T* null_ptr_;
public:

    explicit my_ptr() {
        _data = null_ptr_;
        cout << "my_ptr constructed." << endl;
    }

    explicit my_ptr(T a): _data(&a) {
        cout << "my_ptr constructed." << endl;
    }

    explicit my_ptr(T* ptr): _data(ptr) {
        cout << "my_ptr constructed." << endl;
    }

    my_ptr& operator=(const my_ptr& src) {
        cout << "Copying of my_ptr is forbidden!" << endl;
        cout << "my_ptr updated." << endl;
        return *this;
    };

    my_ptr (const my_ptr& src) {
        cout << "Copying of my_ptr is forbidden!" << endl;
        this -> _data = this -> null_ptr_;
        cout << "my_ptr constructed." << endl;
    };

    my_ptr (my_ptr&& src) {
        this -> _data = src._data;
        src._data = null_ptr_;
        cout << "my_ptr constructed." << endl;
    }

    my_ptr& operator=(my_ptr&& src) {
        if (_data != null_ptr_) {
            delete _data;
        }
        this -> _data = src._data;
        src._data = null_ptr_;
        cout << "my_ptr updated." << endl;
        return *this;
    }

    T& operator* () const noexcept {
        if (_data == null_ptr_) {
            cout << "Do not attempt to read a nullptr!" << endl;
        }
        return *_data;
    }

    T* operator->() const noexcept {
        if (_data == null_ptr_) {
            cout << "Do not attempt to read a nullptr!" << endl;
        }
        return _data;
    }

    ~my_ptr() { 
        if ( _data != null_ptr_) {
            delete _data;
        }
        cout << "my_ptr destructed." << endl;
    };
};

template<typename T>
T* my_ptr<T>::null_ptr_ = new T;